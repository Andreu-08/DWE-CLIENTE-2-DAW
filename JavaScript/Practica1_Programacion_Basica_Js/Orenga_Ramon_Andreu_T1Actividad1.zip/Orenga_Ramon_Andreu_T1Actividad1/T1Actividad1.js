// Tipos de datos

// b) Un archivo “js” que genere 3 mensajes de alerta (se usará la función “alert”) para
// mostrar los siguientes mensajes:

// 1. El primer mensaje debe mostrar el mensaje de alerta “Hola mundo”. 

alert("Hola mundo")

// 2. El segundo mensaje debe mostrar una constante que se haya definido con
// vuestro nombre completo (Nombre + Apellido1 + Apellido2).

const nombreCompleto = 'Andreu Orenga Ramon'
alert(nombreCompleto);

// 3. El tercer mensaje debe mostrar que el comando alert es realmente una función
// específica de javascript.

alert('El comando alert es realmente una función específica de javascript');