// Practica Ejercicio 4

// 4. Introducir un número y decir si es par o impar.

//Promp para introducir el numero
let num = prompt('Introduce un numero para saber si es par o impar')

//comprovamos si el numero es par o impar para mostrar el mensaje

if (num % 2 == 0){
    alert('El numero es par');
}else{
    alert('El numero es impar');
}
